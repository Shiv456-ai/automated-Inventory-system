async function main() {
    const [deployer] = await ethers.getSigners();
    const InventoryManager = await ethers.getContractFactory("InventoryManager");
    const contract = await InventoryManager.deploy();
    console.log("contract deployed to:", contract.target);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });