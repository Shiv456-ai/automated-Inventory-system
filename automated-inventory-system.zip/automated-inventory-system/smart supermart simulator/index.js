const { Web3 } = require("web3");

const web3 = new Web3(
  new Web3.providers.HttpProvider("http://127.0.0.1:8545/")
); 

const abi =
  require("../blockchain/artifacts/contracts/InventoryManager.sol/InventoryManager.json").abi;

const contractAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3"; 
const contract = new web3.eth.Contract(abi, contractAddress);

async function registerUser(address, name, password, cnic) {
  try {
    const result = await contract.methods
      .register(address, name, password, cnic)
      .send({ from: address });
    console.log("User registered successfully:", result);
    return result;
  } catch (error) {
    console.error("Error registering user:", error);
  }
}

async function loginUser(address, password) {
  try {
    const result = await contract.methods
      .login(address, password)
      .send({ from: address });
    console.log("User logged in successfully:", result);
    return result;
  } catch (error) {
    console.error("Error logging in user:", error);
  }
}

async function logoutUser(address) {
  try {
    const result = await contract.methods
      .logout(address)
      .send({ from: address });
    console.log("User logged out successfully:", result);
    return result;
  } catch (error) {
    console.error("Error logging out user:", error);
  }
}

async function addInventory(
  totalUnits,
  costPricePerUnit,
  productId,
  senderAddress
) {
  try {
    const result = await contract.methods
      .addInventory(totalUnits, costPricePerUnit, productId)
      .send({ from: senderAddress });
    console.log("Inventory added successfully:", result);
    return result;
  } catch (error) {
    console.error("Error adding inventory:", error);
  }
}

async function addProduct(productName, upc, sellPrice, storeId, senderAddress) {
  try {
    const result = await contract.methods
      .addProduct(productName, upc, sellPrice, storeId)
      .send({ from: senderAddress, gas: 300000 });
    console.log("Product added successfully:", result);
    return result;
  } catch (error) {
    console.error("Error adding product:", error);
  }
}

async function updateProductPrice(productId, sellPrice, senderAddress) {
  try {
    const result = await contract.methods
      .updateProductPrice(productId, sellPrice)
      .send({ from: senderAddress });
    console.log("Product price updated successfully:", result);
    return result;
  } catch (error) {
    console.error("Error updating product price:", error);
  }
}

async function addStore(storeName, storeLocation, senderAddress) {
  try {
    const result = await contract.methods
      .addStore(storeName, storeLocation)
      .send({ from: senderAddress });
    console.log("Store added successfully:", result);
    return result;
  } catch (error) {
    console.error("Error adding store:", error);
  }
}

async function addSale(productId, quantity, senderAddress) {
  try {
    const result = await contract.methods
      .addSale(productId, quantity)
      .send({ from: senderAddress });
    console.log("Sale added successfully:", result);
    return result;
  } catch (error) {
    console.error("Error adding sale:", error);
  }
}

async function getAllStores(userAddress) {
  try {
    const result = await contract.methods.getAllStores().call();
    const filteredResults = result.filter(
      (element) =>
        element.userAddress.toLowerCase() == userAddress?.toLowerCase()
    );
    console.log("All stores:", filteredResults);
    return filteredResults;
  } catch (error) {
    console.error("Error getting all stores:", error);
  }
}

async function getAllProducts(storeId) {
  try {
    const result = await contract.methods.getAllProducts().call();
    const filteredResults = result.filter(
      (element) => element.storeId.toString() == storeId
    );
    console.log("All products:", filteredResults);
    return filteredResults;
  } catch (error) {
    console.error("Error getting all products:", error);
  }
}

async function getAllInventoryProducts(productId) {
  try {
    const result = await contract.methods.getAllInventoryProducts().call();
    const filteredResults = result.filter(
      (element) => element.productId == productId
    );
    console.log("All inventory products:", filteredResults);
    return filteredResults;
  } catch (error) {
    console.error("Error getting all inventory products:", error);
  }
}

async function getTotalInventoryOfAProduct(productId) {
  try {
    const result = await contract.methods
      .getTotalInventoryOfAProduct(productId)
      .call();
    console.log("getTotalInventoryOfAProduct:", result);
    return result;
  } catch (error) {
    console.error("Error getting getTotalInventoryOfAProduct:", error);
  }
}
