import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../stores.css'; 
import { getAllStores } from '../simulator';

const Stores = () => {
    const [stores, setStores] = useState([]);
    useEffect(() => {
        const fetchStores = async () => {
        try {
            const results= await getAllStores(localStorage.getItem('userAddress'))
            setStores(results);
            console.log(results)
        } catch (error) {
            console.error('Error fetching stores:', error);
        }
    };
    fetchStores();
    }, []);

    

    return (
        <div className="stores-container">
            <h1 className="stores-heading">My Stores</h1>
            <Link to="/add-store">
                <button className="add-store-button">Add Store</button>
            </Link>
            <table className="store-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Total Sales</th>
                        <th>Sold Inventory Cost</th>
                        <th>Total Profit</th>
                    </tr>
                </thead>
                <tbody>
                    {stores.map(store => (
                        <tr key={store.id}>
                            <td>{store.id.toString()}</td>
                            <td>{store.storeName}</td>
                            <td>{store.location}</td>
                            <td>{store.totalSales.toString()}</td>
                            <td>{store.totalCost.toString()}</td>
                            <td>{store.totalProfit.toString()}</td>
                            <td>
                                <Link to={`/view-prodcut/${store.id}`}>
                                    <button>View Product</button>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Stores;
