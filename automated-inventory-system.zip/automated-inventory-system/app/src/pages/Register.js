import React from "react";
import { useNavigate } from "react-router-dom";
import { registerUser } from "../simulator";
import { useState } from "react";

const Register = () => {
  const navigate = useNavigate("");
  const [address, setAddress] = useState("");
  const [name, setName] = useState("");
  const [password, setPass] = useState("");
  const [cnic, setCnic] = useState("");

  const recordAddress = (e) => {
    setAddress(e.target.value);
  };
  const recordName = (e) => {
    setName(e.target.value);
  };
  const recordPass = (e) => {
    setPass(e.target.value);
  };
  const recordNIC = (e) => {
    setCnic(e.target.value);
  };
  const validateLogin = () => {
    
    registerUser(address,name,password,cnic);
    navigate(-1);
  };
  return (
    <div className="home">
      <div className="logincard grid">
        <div class="input-group">
          <label class="label">User Address</label>
          <input
            autocomplete="off"
            name="Email"
            id="Email"
            class="input"
            type="email"
            onChange={recordAddress}
          />
        </div>
        <div class="input-group">
          <label class="label">Name</label>
          <input
            autocomplete="off"
            name="Email"
            id="Email"
            class="input"
            type="email"
            onChange={recordName}
          />
        </div>
        <div class="input-group">
          <label class="label">Password</label>
          <input
            autocomplete="off"
            name="Email"
            id="Email"
            class="input"
            type="email"
            onChange={recordPass}
          />
        </div>
        <div class="input-group">
          <label class="label">National ID</label>
          <input
            autocomplete="off"
            name="Email"
            id="Email"
            class="input"
            type="email"
            onChange={recordNIC}
          />
        </div>
        <button className="btn" onClick={validateLogin}>
          Register
        </button>
      </div>
    </div>
  );
};

export default Register;
