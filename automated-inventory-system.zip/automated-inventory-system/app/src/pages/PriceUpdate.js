import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { addInventory, updateProductPrice } from "../simulator";

const UpdatePrice = () => {
  const { itemId } = useParams();
  const navigate = useNavigate();
  const [pricePerUnit, setPrice] = useState("");

  const priceHandler = (e) => {
    setPrice(e.target.value);
  };

  const callUpdate = () => {
    try {
      updateProductPrice(
        itemId,
        pricePerUnit,
        localStorage.getItem("userAddress")
      );
      alert("Price Updated");
      navigate(-1);
    } catch (error) {
        console.log('sorry')
    }
  };

  return (
    <div className="home">
      <div className="wrapper">
        <form action="">
          <p className="form-login">Enter New Sale Price</p>

          <div className="input-box">
            <input
              required=""
              placeholder="Sale Price Per Unit"
              type="number"
              onChange={priceHandler}
            />
          </div>
          <button className="btn" type="button" onClick={callUpdate}>
            Update
          </button>
        </form>
      </div>
    </div>
  );
};

export default UpdatePrice;
