import React, { useState, useEffect } from "react";
import { getAllInventoryProducts } from "../simulator";
import { useParams, useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";

const ViewInventory = () => {
  const [inventory, setInventory] = useState([]);
  const { itemId } = useParams();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const result = await getAllInventoryProducts(itemId);
        setInventory(result);
        console.log(result);
      } catch (error) {
        console.log("Error");
      }
    };

    fetchProduct();
  }, [itemId]);

  return (
    <div className="stores-container">
      <h1 className="stores-heading">My Products</h1>
      <Link to={`/update-inventory/${itemId}`}>
        <button className="add-store-button">Add Inventory</button>
      </Link>
      <table className="store-table">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Cost Price</th>
            <th>Quantity</th>
            <th>Sold Units</th>

          </tr>
        </thead>
        <tbody>
          {inventory.map((product) => (
            <tr key={product.id}>
              <td>{product.productName}</td>
              <td>{product.costPricePerProduct.toString()}</td>
              <td>{product.totalUnits.toString()}</td>
              <td>{product.soldUnits.toString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewInventory;
