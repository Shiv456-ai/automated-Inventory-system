import React from 'react'
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addStore } from '../simulator';


const AddStore = () => {
    const navigate = useNavigate(); // Use useNavigate hook to get the navigate function
    const [name, setName] = useState('');
    const [loc, setLoc] = useState('');



    const nameHandler = (e) => {
        setName(e.target.value);
    };

    
    const locHandler = (e) => {
        setLoc(e.target.value);
    };


    const callAdd = () => {
         try {
            addStore(name,loc,localStorage.getItem('userAddress'))
            navigate(-1); 
         } catch (error) {
            alert('Sorry! Cant Add Store')
            
         }
        
    };



  return (
    <div className='home'>
    <div className="wrapper">
        <form action="">
            <p className="form-login">Add Store</p>
            
            <div className="input-box">
                <input required="" placeholder="Store Name" type="text" onChange={nameHandler} />
            </div>
            <div className="input-box">
                <input required="" placeholder="Location" type="text" onChange={locHandler} />
            </div>
          
          <button className="btn" type="button" onClick={callAdd}>Add</button>
        </form>
    </div>
</div>  )
}

export default AddStore