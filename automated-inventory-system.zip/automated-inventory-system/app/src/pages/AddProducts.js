import React from 'react'
import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { addProduct } from '../simulator';

const AddProducts = () => {
    const { storeId } = useParams();

    const navigate = useNavigate(); 
    const [name, setName] = useState('');
    const [upc, setUPC] = useState('');
    const [price,setPrice]= useState('')

    const upcHandler = (e) => {
        setUPC(e.target.value);
    };
    const nameHandler = (e) => {
        setName(e.target.value);
    };
    const priceHandler = (e) => {
        setPrice(e.target.value);
    };



   
    const callAdd = () => {
        
        try {
            addProduct(name,upc,price,storeId,localStorage.getItem('userAddress'))
           navigate(-1); 
            
        } catch (error) {

            alert('Wrong Inputs.')
            
        }
    };

  return (
    <div className='home'>
    <div className="wrapper">
        <form action="">
            <p className="form-login">Add Product</p>
            
            <div className="input-box">
                <input required="" placeholder="Product Name" type="text" onChange={nameHandler} />
            </div>
            <div className="input-box">
                <input required="" placeholder="Product UPC" type="text" onChange={upcHandler} />
            </div>
            <div className="input-box">
                <input required="" placeholder="Sell Price" type="number" onChange={priceHandler} />
            </div>
            <button className="btn" type="button" onClick={callAdd}>ADD</button>
        </form>
    </div>
</div>  )
}

export default AddProducts