import React, { useState ,useEffect} from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { addInventory } from '../simulator';

const UpdateInventory = () => {
    const { itemId } = useParams();
    const navigate = useNavigate(); 
    const [units, setUnits] = useState('');
    const [pricePerUnit, setPrice] = useState('');

    

    const unitsHandler = (e) => {
        setUnits(e.target.value);
    };

    const priceHandler = (e) => {
        setPrice(e.target.value);
    };

    const callUpdate = () => {
        addInventory(units, pricePerUnit, itemId, localStorage.getItem('userAddress'));

        navigate(-1); 
    };

    return (
        <div className='home'>
            <div className="wrapper">
                <form action="">
                    <p className="form-login">Update</p>
                    <div className="input-box">
                        <input required="" placeholder="Inventory Units" type="number" onChange={unitsHandler} />
                    </div>
                    <div className="input-box">
                        <input required="" placeholder="Cost Per Unit" type="number" onChange={priceHandler} />
                    </div>
                    <button className="btn" type="button" onClick={callUpdate}>Update</button>
                </form>
            </div>
        </div>
    );
}

export default UpdateInventory;
