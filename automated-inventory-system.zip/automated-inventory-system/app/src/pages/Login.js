import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { loginUser } from "../simulator";

const Login = () => {
  const [address, setAddress] = useState("");
  const [password, setPass] = useState("");
  const recordAddress = (e) => {
    setAddress(e.target.value);
  };
  const recordPass = (e) => {
    setPass(e.target.value);
  };

  const navigate = useNavigate("");

  const validateLogin = async () => {

    
      const result= await loginUser(address, password);
      if(result){
        localStorage.setItem("userAddress", address);
        navigate("/mystores");
      }
      else{

        alert("Wrong UserAddress or Passwor!");
      }
      
  };

  return (
    <div className="home">
      <img src="/login.png" alt="" />
      <div className="logincard">
        <div class="input-group">
          <label class="label">Enter UserAddress</label>
          <input
            autocomplete="off"
            name="Email"
            id="Email"
            class="input"
            type="email"
            onChange={recordAddress}
          />
          <div></div>
        </div>
        <div class="input-group">
          <label class="label">Enter Password</label>
          <input
            autocomplete="off"
            name="Email"
            id="Email"
            class="input"
            type="password"
            onChange={recordPass}
          />
          <div></div>
        </div>

        <button className="btn" onClick={validateLogin}>
          Login
        </button>
      </div>
      <div>
        <p>
          Not a member?{" "}
          <Link to="/register">
            <span>Register Now</span>
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
