import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
 
  return (

    <div className='home'>
      <h1>Inventory Management System</h1>
      <img src='/inventory.png' alt='img'/>
      <Link to='/login' className='link'><button >Enter the System</button></Link>
      
     </div>
  )
}

export default Home