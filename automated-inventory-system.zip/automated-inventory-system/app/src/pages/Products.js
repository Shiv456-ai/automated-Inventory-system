import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getAllProducts } from '../simulator';

const ProductPage = () => {
    const { storeId } = useParams();
    const [products, setProducts] = useState([]);
    console.log(storeId, 'storeid');

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const result= await getAllProducts(storeId)
                setProducts(result);
                console.log(result);
            } catch (error) {
                console.log('Error fetching Products:');
            }
        };

        fetchProduct();
    }, [storeId]);

    return (
        <div className="stores-container">
            <h1 className="stores-heading">My Products</h1>
            <Link to={`/add-products/${storeId}`}>
                <button className="add-store-button">Add Product</button>
            </Link>
            <table className="store-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Store Name</th>
                        <th>Sale Price</th>
                    </tr>
                </thead>
                <tbody>
                    {products.map(item => (
                        <tr key={item.id}>
                            <td>{item.id.toString()}</td>
                            <td>{item.productName}</td>
                            <td>{item.storeName}</td>
                            <td>{item.sellPrice.toString()}</td>
                            <td>
                                <Link to={`/view-inventory/${item.id}`}>
                                    <button>View Inventory</button>
                                </Link>
                            </td>
                            <td>
                                <Link to={`/update-price/${item.id}`}>
                                    <button>Update</button>
                                </Link>
                            </td>

                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ProductPage;
