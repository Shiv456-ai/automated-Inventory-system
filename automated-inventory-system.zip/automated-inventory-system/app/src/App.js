import './App.css';
import Home from './pages/Home';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Stores from './pages/Stores';
import UpdateInventory from './pages/UpdateInventory';
import AddStore from './pages/AddStore';
import ProductPage from './pages/Products';
import AddProducts from './pages/AddProducts';
import Register from './pages/Register';
import UpdatePrice from './pages/PriceUpdate';
import ViewInventory from './pages/ViewInventory';

function App() {
  return (
   <>
     <Router>
      <Routes>
        <Route path='/' element={<Home/>}></Route>
        <Route path='/login' element={<Login/>}></Route>
       <Route path='/register' element={<Register/>}></Route>
        <Route path='/mystores' element={<Stores/>}></Route>
        <Route path='/view-prodcut/:storeId' element={<ProductPage/>}></Route>
        <Route path='/view-inventory/:itemId' element={<ViewInventory/>}></Route>
        <Route path='/update-inventory/:itemId' element={<UpdateInventory/>}></Route>
        <Route path='/update-price/:itemId' element={<UpdatePrice/>}></Route>
        <Route path='/add-store' element={<AddStore/>}>
        </Route> <Route path='/add-products/:storeId' element={<AddProducts/>}></Route>



        update-inventory


      </Routes>
     </Router>
   </>
  );
}

export default App;
